function g = sigmoid(z)
%SIGMOID Compute sigmoid functoon
%   J = SIGMOID(z) computes the sigmoid of z.

% You need to return the following variables correctly 
g = zeros(size(z));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the sigmoid of each value of z (z can be a matrix,
%               vector or scalar).

%g = exp(z);
%g = g .^ (-1);
%g = g .+ 1;
%g = g .^ (-1);

%g = 1 ./ (1 .+ exp(-z));

for i1 = 1:size(z,1)
	for j1 = 1:size(z,2)
		g(i1,j1) = 1 ./ (1 .+ exp(-z(i1,j1) ) );
	end
end
% =============================================================

end
